package Utilities;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelReader {

	static XSSFWorkbook workbook;
	static XSSFSheet sheet;
	static XSSFCell cell;
	static String ProjectPath = System.getProperty("user.dir");
	static String StringData;
	static double numericData;
		
	public static String getStringData(int rownum, int colnum) {
		
		try {
		
			workbook = new XSSFWorkbook(ProjectPath+"/TestData/TestData.xlsx");
			sheet = workbook.getSheet("TestData");
			StringData = sheet.getRow(rownum).getCell(colnum).getStringCellValue();
			
		} 
		
		catch (Exception e) {
			e.printStackTrace();
		}
		return StringData;
	}
	
	public static double getNumericData(int rownum, int colnum) {
		
		try {
	
			workbook = new XSSFWorkbook(ProjectPath+"/TestData/TestData.xlsx");
			sheet = workbook.getSheet("TestData");
			numericData = sheet.getRow(rownum).getCell(colnum).getNumericCellValue();
			
		} 
		
		catch (Exception e) {
			e.printStackTrace();
		}
		return numericData;
	}
}
