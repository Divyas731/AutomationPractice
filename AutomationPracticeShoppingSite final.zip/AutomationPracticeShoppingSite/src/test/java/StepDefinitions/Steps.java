package StepDefinitions;

import java.util.concurrent.TimeUnit;

import org.apache.commons.lang3.RandomStringUtils;
import org.junit.Assert;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import PageObjects.LoginPage;
import PageObjects.PurchasePage;
import PageObjects.RegisterPage;
import PageObjects.SearchPage;
import PageObjects.WishlistPage;
import Utilities.ExcelReader;
import io.cucumber.java.en.*;

public class Steps{
	
	
	String ProjectPath = null;
	public WebDriver driver = null;
	public LoginPage lp;
	public RegisterPage rp;
	public SearchPage sp;
	public WishlistPage wp;
	public PurchasePage pp;
	String GeneratedString = RandomStringUtils.randomAlphanumeric(7);
	String Randomemail = GeneratedString+"@gmail.com";
	String ActualPrice = null;
	String ActualQuantity = null;
	String InitialQty = null;
	
	@Given("user launch chrome browser")
	public void user_launch_chrome_browser() {
		ProjectPath = System.getProperty("user.dir");
	    System.setProperty("webdriver.chrome.driver", ProjectPath+"/Drivers/chromedriver.exe");
	    driver = new ChromeDriver();
	    driver.manage().window().maximize();
	    driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	    driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
	    lp = new LoginPage(driver);
	    rp = new RegisterPage(driver);
	    sp = new SearchPage(driver);
	    pp = new PurchasePage(driver);
	    wp = new WishlistPage(driver);
	}

	@Then("user opens url {string}")
	public void user_opens_url(String url) throws InterruptedException {
		
	    driver.get(url);
	    Thread.sleep(3000);
	}

	@Then("user enters username as {string} and password as {string}")
	public void user_enters_username_as_and_password_as(String email, String password) throws InterruptedException {
		
		lp.setEmailAddress(email);
		lp.setPassword(password);
		Thread.sleep(3000);
	    
	}

	@And("clicks on the signin button")
	public void clicks_on_the_signin_button() throws InterruptedException {
		
		lp.clickLogin();
		Thread.sleep(3000);
	    
	}

	@Then("page title should be {string}")
	public void page_title_should_be(String title) throws InterruptedException {
		
		if(driver.getPageSource().contains("There is 1 error")) {
			driver.close();
			Assert.assertTrue(false);
		}
		
		else {
			Assert.assertEquals(title, driver.getTitle());
		}
		Thread.sleep(3000);
	    
	}
	
	@Then("user verifies that the message is displayed as {string}")
	public void verify_that_message_displayed(String errorMessage) throws InterruptedException {
		
		if(driver.getPageSource().contains(errorMessage)) {
			Assert.assertTrue(true);
		}
		Thread.sleep(3000);

	}

	@When("user clicks on sign out link")
	public void user_clicks_on_sign_out_link() throws InterruptedException {
		
		lp.clickLogout();
		Thread.sleep(3000);
	    
	}

	@And("close the browser")
	public void close_the_browser() {
		
		driver.close();
	    
	}
	
	//StepDefinitions for Register new user
	
	@When("user enters email address")
	public void user_enters_email_address() throws InterruptedException {
		
		rp.txt_email(Randomemail);
		Thread.sleep(3000);
	}
	
	@And("click on create an account button")
	public void click_on_create_an_account_button() throws InterruptedException {
		rp.btn_Create();
		Thread.sleep(3000);
		
	}
	
	@And("user enters all the mandatory fields from given {string} and {int}")
	public void user_enters_all_the_mandatory_fields(String sheetName, int RowNum) throws InterruptedException {
		
		String title = ExcelReader.getStringData(RowNum, 0);
		rp.setGender(title);
		String FirstName1 = ExcelReader.getStringData(RowNum, 1);
		rp.setFirstName(FirstName1);
		String LastName1 = ExcelReader.getStringData(RowNum, 2);
		rp.setLastName(LastName1);
		String password1 = ExcelReader.getStringData(RowNum, 3);
		rp.setPassword(password1);
		if(RowNum==1) {
		double Day_DOB1 = ExcelReader.getNumericData(RowNum, 4);
		rp.setDOB_Day((int)Day_DOB1);
		String Day_Month1 = ExcelReader.getStringData(RowNum, 5);
		rp.setDOB_Month(Day_Month1);
		double Day_Year1 = ExcelReader.getNumericData(RowNum, 6);
		rp.setDOB_Year((int)Day_Year1);
		}
		String custFName1 = ExcelReader.getStringData(RowNum, 7);
		rp.verifyFirstName(custFName1);
		String custLName1 = ExcelReader.getStringData(RowNum, 8);
		rp.verifyLastName(custLName1);
		String Address1 = ExcelReader.getStringData(RowNum, 9);
		rp.setAddress1(Address1);
		String City1 = ExcelReader.getStringData(RowNum, 10);
		rp.setCity(City1);
		String State1 = ExcelReader.getStringData(RowNum, 11);
		rp.setState(State1);
		String Country1 = ExcelReader.getStringData(RowNum, 12);
		rp.setCountry(Country1);
		if(RowNum==1) {
		double zipCode1 = ExcelReader.getNumericData(RowNum, 13);
		String Zip = String.valueOf((int)zipCode1);
		rp.setZipCode(Zip);
		}
		else if(RowNum == 2) {
			String Zip = ExcelReader.getStringData(RowNum, 13);
			rp.setZipCode(Zip);
		}
		rp.setMobile("9704183190");
		Thread.sleep(3000);
		
		
	}
	
	@And("clicks on register button")
	public void clicks_on_register_button() throws InterruptedException {
		rp.clickRegisterButton();
		Thread.sleep(3000);
		
	}
	
	@Then("user enters username as {string}")
	public void user_enters_username_as(String UserName) {
		rp.txt_email(UserName);
	}
	
	// StepDefinitions for Search page
	@Then("user enters {string} in search bar")
	public void user_enters_in_Search_bar(String searchValue) throws InterruptedException {
		sp.searchMethod(searchValue);
		Thread.sleep(3000);
	}
	
	@And("click on search button")
	public void click_on_search_button() throws InterruptedException {
		sp.ClickSearchButton();
		Thread.sleep(3000);
	}
	
	@And("verify search is successful")
	public void verify_search_is_successful() {
		sp.VerifySearchWithHeading();
		sp.verifySearchWithResults();
		
	}
	
	@And("verify no results message in search result")
	public void verify_no_results_message_in_search_result() {
		sp.verifyInvalidSearch();
	}
	
	//Step Definitions for wish list page
	
	@When("user hover on the summer dress in search results")
	public void user_hover_on_the_summer_dress_in_search_results() throws InterruptedException {
		wp.searchSummerDress();
		Thread.sleep(3000);
	}
	
	@And("click on my wishlist link")
	public void click_on_my_wishlist_link() {
		wp.clickOnMyWishlist();
	}
	
	@Then("click on the add to wishlist button")
	public void click_on_the_add_to_wishlist_button() {
		wp.clickOnAddToWishlist();
	}
	
	@Then("click on the popup close button")
	public void click_on_the_popup_close_button() {
		wp.clickOnCloseButton();
	}
	
	@Then("click on the view button")
	public void click_on_the_view_button() {
		wp.clickOnViewButton();
	}
	
	@And("click on the remove button")
	public void click_on_the_remove_button() {
		wp.clickOnRemoveButton();
	}
	
	@When("user scroll down")
	public void user_scroll_down() {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,350)", "");
	}
	
	//Step definitions for purchase page
	
	@Given("user verifies {string} message is displayed")
	public void user_verifies(String errorMessage) throws InterruptedException {
		if(driver.getPageSource().contains(errorMessage)) {
			Assert.assertTrue(true);
		}
		Thread.sleep(3000);
	}
	
	@Then("hover on the cart and click on checkout button")
	public void hover_on_the_cart_and_click_on_checkout_button() throws InterruptedException {
		pp.hoverOnCart();
		Thread.sleep(2000);
		pp.clickOnCheckout();
	}
	
	@Then("click on the more button")
	public void click_on_the_more_button() throws InterruptedException {
		pp.clickMoreButton();
		Thread.sleep(3000);
	}
	
	@And("choose the color blue")
	public void choose_the_color_blue() throws InterruptedException {
		pp.selectBlueDress();
		Thread.sleep(3000);
		ActualPrice = pp.getActualPrice();
		ActualQuantity = pp.getActualQuantity();
	}
	
	@Then("clicks on add to cart button")
	public void clicks_on_add_to_cart_button() throws InterruptedException {
		pp.clickAddToCartButton();
		Thread.sleep(3000);
	}
	
	@Then("click on proceed to checkout button")
	public void click_on_proceed_to_checkout_button() throws InterruptedException {
		pp.clickProceedToCheckoutButton();
		Thread.sleep(3000);
	}
	
	@And("verify the invoice values")
	public void verify_the_invoice_values() {
		System.out.println(ActualPrice);
		System.out.println(ActualQuantity);
		if(ActualPrice.equalsIgnoreCase(pp.getInvoicePrice()) && ActualQuantity.equalsIgnoreCase(pp.getInvoiceQuantity())) {
			Assert.assertTrue(true);
		}
		else {
			Assert.assertTrue(false);
		}
	}
	
	@Then("click on proceed to checkout button in summary")
	public void click_on_proceed_to_checkout_button_in_summary() throws InterruptedException {
		pp.ClickProceedToCheckoutInSummary();
		Thread.sleep(30003);
	}
	
	@And("give comments as {string}")
	public void give_comments_as(String comments) throws InterruptedException {
		pp.writeComments(comments);
		Thread.sleep(3000);
	}
	
	@And("read the terms of services")
	public void read_the_terms_of_service() throws InterruptedException {
		pp.readTerms();
		Thread.sleep(2000);
		pp.checkTerms();
		Thread.sleep(3000);
		pp.closeTerms();
		Thread.sleep(2000);
	}
	
	@Then("accept the terms of services")
	public void accept_the_terms_of_services() throws InterruptedException {
		pp.acceptTerms();
		Thread.sleep(3000);
	}
	
	@Then("choose payment options as {string}")
	public void choose_payment_options_as(String option) {
		pp.setPaymentOption(option);
	}
	
	@And("click on i confirm my order button")
	public void click_on_i_confirm_my_order_button() throws InterruptedException {
		pp.clickConfirmOrder();
		Thread.sleep(3000);
	}

}
