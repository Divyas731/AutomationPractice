package PageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;

public class PurchasePage {

WebDriver driver;
	
	public PurchasePage(WebDriver driver) {
		this.driver = driver;
	}
	
	By ViewCart = By.xpath("//a[@title='View my shopping cart']");
	By Checkout_btn = By.xpath("//span[contains(text(),'Check out')]");
	
	By More_btn = By.xpath("(//span[contains(text(),'More')])[1]");
	
	By Select_Blue = By.xpath("//a[@name='Blue']");
	By AddToCart_btn = By.xpath("//span[text()='Add to cart']");
	By ActualPrice = By.xpath("//span[@id='our_price_display']");
	By ActualQuantity = By.xpath("//input[@id='quantity_wanted']");
	By ProceedToCheckout_btn = By.xpath("//span[contains(text(),'Proceed to checkout')]");
	
	By InvoicePrice = By.xpath("//span[contains(@id,'total_product_price')]");
	By InvoiceQuantity = By.xpath("//input[@class='cart_quantity_input form-control grey']");
	
	By CheckoutInSummary = By.xpath("(//span[contains(text(),'Proceed to checkout')])[2]");
	
	By CommentsMessage = By.xpath("//textarea[@name='message']");
	
	By ReadTerms = By.xpath("//a[text()='(Read the Terms of Service)']");
	By TermsHeading = By.xpath("//h1[text()='Terms and conditions of use']");
	By CloseTerms = By.xpath("//a[@title='Close']");
	
	By AcceptTerms = By.xpath("//input[@id='cgv']");
	
	By PaymentOption_Bankwire = By.xpath("//a[@class='bankwire']");
	By PaymentOption_Cheque = By.xpath("//a[@class='cheque']");
	
	By ConfirmOrder_btn = By.xpath("//span[contains(text(),'I confirm my order')]");
	
	public void hoverOnCart() {
		Actions action = new Actions(driver);
		action.moveToElement(driver.findElement(ViewCart)).perform();
	}
	
	public void clickOnCheckout() {
		driver.findElement(Checkout_btn).click();
	}
	
	public void clickMoreButton() {
		driver.findElement(More_btn).click();
	}
	
	public void selectBlueDress() {
		driver.findElement(Select_Blue).click();
	}
	public String getActualPrice() {
		String Price = driver.findElement(ActualPrice).getText();
		return Price;
	}
	
	public String getActualQuantity() {
		String Qty = driver.findElement(ActualQuantity).getAttribute("value").toString();
		return Qty;
	}
	
	public String getInvoicePrice() {
		String price = driver.findElement(InvoicePrice).getText();
		return price;
	}
	
	public String getInvoiceQuantity() {
		String qty = driver.findElement(InvoiceQuantity).getAttribute("value");
		return qty;
	}
	
	public void clickAddToCartButton() {
		driver.findElement(AddToCart_btn).click();
	}
	
	public void clickProceedToCheckoutButton() {
		driver.findElement(ProceedToCheckout_btn).click();
	}
	
	public void ClickProceedToCheckoutInSummary() {
		driver.findElement(CheckoutInSummary).click();
	}
	
	public void writeComments(String comments) {
		driver.findElement(CommentsMessage).sendKeys(comments);
	}
	
	public void readTerms() {
		driver.findElement(ReadTerms).click();
	}
	
	public void checkTerms() {
		driver.switchTo().frame(0);
		driver.findElement(TermsHeading).isDisplayed();
	}
	
	public void closeTerms() {
		driver.switchTo().defaultContent();
		driver.findElement(CloseTerms).click();
	}
	
	public void acceptTerms() {
		
		WebElement Terms = driver.findElement(AcceptTerms);
		if(Terms.isSelected() == false) {
			Terms.click();
		}
	}
	
	public void setPaymentOption(String Option) {
		if(Option.equalsIgnoreCase("Bankwire")) {
			driver.findElement(PaymentOption_Bankwire).click();;
		}
		else if(Option.equalsIgnoreCase("Cheque")) {
			driver.findElement(PaymentOption_Cheque).click();
		}
	}
	
	public void clickConfirmOrder() {
		driver.findElement(ConfirmOrder_btn).click();
	}
}
