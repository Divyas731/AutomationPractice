package PageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class SearchPage {
	
	WebDriver driver;
	
	public SearchPage(WebDriver driver) {
		this.driver = driver;
	}
	
	By Search_Edit = By.xpath("//input[@id='search_query_top']");
	By Search_Btn = By.xpath("//button[@name='submit_search']");
	
	By Search_Heading = By.xpath("//span[contains(text(),'summer dress in blue')]");
	By Search_Result = By.xpath("//span[contains(text(),'results have been found')]");
	
	By invalid_search = By.xpath("//p[contains(text(),'No results were found')]");
	
	public void searchMethod(String SearchValue) {
		driver.findElement(Search_Edit).sendKeys(SearchValue);
	}
	
	public void ClickSearchButton() {
		driver.findElement(Search_Btn).click();
	}
	
	public void VerifySearchWithHeading() {
		driver.findElement(Search_Heading).isDisplayed();
	}
	
	public void verifySearchWithResults() {
		driver.findElement(Search_Result).isDisplayed();
	}
	
	public void verifyInvalidSearch() {
		driver.findElement(invalid_search).isDisplayed();
	}

}
