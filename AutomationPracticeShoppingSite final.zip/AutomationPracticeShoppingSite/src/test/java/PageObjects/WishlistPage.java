package PageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;

public class WishlistPage {
	
	WebDriver driver;
	
	public WishlistPage(WebDriver driver) {
		this.driver = driver;
	}
	
	By Summer_Dress = By.xpath("//div[@class='right-block']//a[contains(text(),'Printed Summer Dress')]");
	By WishList_btn = By.xpath("//a[@class='addToWishlist wishlistProd_5']");
	By Close_btn = By.xpath("//a[@title='Close']");
	By MyWishlistLink = By.xpath("//a[@title='My wishlists']");
	By view_btn = By.xpath("//a[contains(text(),'View')]");
	By remove_btn = By.xpath("//i[@class='icon-remove-sign']");
//	By wishlistTable = By.xpath("//table[@class='table table-bordered']");
//	By wishlistQty = By.xpath("(//tr[contains(@id,'wishlist')]//td)[2]");
	
	public void searchSummerDress() {
		Actions action = new Actions(driver);
		action.moveToElement(driver.findElement(Summer_Dress)).perform();
	}
	
	public void clickOnAddToWishlist() {
		driver.findElement(WishList_btn).click();
	}
	
	public void clickOnCloseButton() {
		driver.findElement(Close_btn).click();
	}
	

	public void clickOnMyWishlist() {
		driver.findElement(MyWishlistLink).click();
	}
	
	public void clickOnViewButton() {
		driver.findElement(view_btn).click();
	}
	
	public void clickOnRemoveButton() {
		driver.findElement(remove_btn).click();
	}
	
//	public boolean checkWishlistTable() {
//		boolean TableDisplay = driver.findElement(wishlistTable).isDisplayed();
//		return TableDisplay;
//	}
//	
//	public int getInitialQty() {
//		String Quantity = driver.findElement(wishlistQty).getText().trim();
//		int Qty = Integer.parseInt(Quantity);
//		return Qty;
//	}

}
