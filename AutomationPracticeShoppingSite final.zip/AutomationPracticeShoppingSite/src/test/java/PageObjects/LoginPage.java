package PageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class LoginPage {

	WebDriver driver;
	
	public LoginPage(WebDriver driver) {
		this.driver = driver;
	}
	
	By txt_email = By.xpath("//input[@id='email']");
	By txt_passwd = By.xpath("//input[@id='passwd']");
	By btn_login = By.xpath("//button[@id='SubmitLogin']");
	By btn_logout = By.xpath("//a[@class='logout']");
	
	public void setEmailAddress(String email) {
		driver.findElement(txt_email).sendKeys(email);
	}
	
	public void setPassword(String pass) {
		driver.findElement(txt_passwd).sendKeys(pass);
	}
	
	public void clickLogin() {
		driver.findElement(btn_login).click();
	}
	
	public void clickLogout() {
		driver.findElement(btn_logout).click();
	}
}
