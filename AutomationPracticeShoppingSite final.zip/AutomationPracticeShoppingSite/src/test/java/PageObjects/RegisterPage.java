package PageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;

public class RegisterPage {
	
	WebDriver driver;
	
	public RegisterPage(WebDriver driver) {
		this.driver = driver;
	}

	By txt_emailAddress = By.xpath("//input[@id='email_create']");
	By btn_CreateAccount = By.xpath("//i[@class='icon-user left']");
	
	By title_Mr = By.xpath("//input[@id='id_gender1']");
	By title_Mrs = By.xpath("//input[@id='id_gender2']");
	
	By firstName = By.xpath("//input[@id='customer_firstname']");
	By lastName = By.xpath("//input[@id='customer_lastname']");
	By email = By.xpath("//input[@id='email']");
	By password = By.xpath("//input[@id='passwd']");
	
	By DOB_Day = By.xpath("//select[@id='days']");
	By DOB_Month = By.xpath("//select[@id='months']");
	By DOB_Year = By.xpath("//select[@id='years']");
	
	By customerFirstName = By.xpath("//input[@id='firstname']");
	By customerLastName = By.xpath("//input[@id='lastname']");
	
	By address1 = By.xpath("//input[@id='address1']");
	By city = By.xpath("//input[@id='city']");
	By state = By.xpath("//select[@id='id_state']");
	By ZipCode = By.xpath("//input[@id='postcode']");
	By country = By.xpath("//select[@id='id_country']");
	
	By mobile = By.xpath("//input[@id='phone_mobile']");
	By aliasAddress = By.xpath("//input[@id='alias']");
	
	By btn_Register = By.xpath("//button[@id='submitAccount']");
	
	public void txt_email(String EmailAddress) {
		driver.findElement(txt_emailAddress).sendKeys(EmailAddress);
	}
	
	public void btn_Create() {
		driver.findElement(btn_CreateAccount).click();
	}
	
	public void setGender(String gender) {
		
		if(gender.equalsIgnoreCase("Mr")) {
			driver.findElement(title_Mr).click();
		}
		else if(gender.equalsIgnoreCase("Mrs")) {
			driver.findElement(title_Mrs).click();
		}
	}
	
	public void setFirstName(String fName) {
		driver.findElement(firstName).sendKeys(fName);
	}
	
	public void setLastName(String lName) {
		driver.findElement(lastName).sendKeys(lName);
	}
	
	public void verifyEmail(String mail) {
		String EmailValue = driver.findElement(email).getAttribute("value");
		if(EmailValue.equals(mail)) {
			System.out.println("Email address is entered");
		}
		else {
			driver.findElement(email).sendKeys(mail);
		}
	}
	
	public void setPassword(String pass) {
		driver.findElement(password).sendKeys(pass);
	}
	
	public void setDOB_Day(int DayValue) {
		Select Day = new Select(driver.findElement(DOB_Day));
		Day.selectByIndex(DayValue);
	}
	
	public void setDOB_Month(String MonthValue) {
		Select Month = new Select(driver.findElement(DOB_Month));
		Month.selectByVisibleText(MonthValue);
	}
	
	public void setDOB_Year(int YearValue) {
		Select Year = new Select(driver.findElement(DOB_Year));
		Year.selectByIndex(YearValue);
	}
	
	public void verifyFirstName(String FName) {
		String FirstNamelValue = driver.findElement(customerFirstName).getAttribute("value");
		if(FirstNamelValue.equals(FName)) {
			System.out.println("Firstname is entered");
		}
		else {
			driver.findElement(customerFirstName).sendKeys(FName);
		}
	}
	
	public void verifyLastName(String LName) {
		String LastNameValue = driver.findElement(customerLastName).getAttribute("value");
		if(LastNameValue.equals(LName)) {
			System.out.println("Lastname is entered");
		}
		else {
			driver.findElement(customerLastName).sendKeys(LName);
		}
	}
	
	public void setAddress1(String Addr) {
		driver.findElement(address1).sendKeys(Addr);
	}
	
	public void setCity(String City) {
		driver.findElement(city).sendKeys(City);
	}
	
	public void setState(String State) {
		Select StateV = new Select(driver.findElement(state));
		StateV.selectByVisibleText(State);
	}
	
	public void setZipCode(String Zip) {
		driver.findElement(ZipCode).sendKeys(Zip);
	}
	
	public void setCountry(String Country) {
		Select CountryV = new Select(driver.findElement(country));
		CountryV.selectByVisibleText(Country);
	}
	
	public void setMobile(String MobileNo) {
		driver.findElement(mobile).sendKeys(MobileNo);
	}
	
	public void clickRegisterButton() {
		driver.findElement(btn_Register).click();
	}

	
}
